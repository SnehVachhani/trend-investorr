"""Trend-Investorr: Authentication package."""
