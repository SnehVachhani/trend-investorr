"""Trend-Investorr: Notifications package."""
