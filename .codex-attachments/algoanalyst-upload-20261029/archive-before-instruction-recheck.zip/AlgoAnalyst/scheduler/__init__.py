"""Trend-Investorr: Scheduler package."""
