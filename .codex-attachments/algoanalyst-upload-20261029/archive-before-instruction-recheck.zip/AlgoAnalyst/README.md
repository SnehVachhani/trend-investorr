# AlgoAnalyst

Python backend for market data collection, stock scanners, strategy evaluation,
and paper or live order execution.

The application code is in `main.py`, with separate modules for market data,
trading, scheduling, storage, and the REST API. Tests are in `tests/`.

## Setup

Use Python 3.12. Run each command separately from this directory:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m pip install -r requirements-dev.txt
```

## Trading regression tests

```sh
.venv/bin/python -m pytest -q tests/trading tests/test_mid_session_restart.py tests/data/test_live_candle_pipeline.py tests/integration/test_signal_to_trade.py
```

These tests use temporary storage, fake services, and simulated broker responses.
They do not require broker credentials, a market feed, or PostgreSQL.

Running the application itself requires separate local configuration and external
services. Personal configuration, credentials, cached market data, and logs are
not included in this source snapshot.
