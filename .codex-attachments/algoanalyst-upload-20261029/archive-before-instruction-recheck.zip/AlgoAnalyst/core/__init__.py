"""Trend-Investorr: Core package."""
