"""Trend-Investorr: Security package."""
